import React from "react";
import Services from "./Component/Services";
 
function App() {
  return (
    <>
<Services />
    </>
  );
}

export default App;
